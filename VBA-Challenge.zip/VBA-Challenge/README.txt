The following folder contains:

* This README file.
* Two macro enabled workbooks, the alphabetical testing and the quarterly stock data workbooks
* Two screenshots, one of the alphabetical testing workbook after code is run, and one 
* of the quarterly stock data after it is run. The quarterly stock data is the most up to date VBA script.
* To the best of my knowledge, I have completed this assignment. There are screenshots, and a readme file.
* I have also included VBA scripts which are in the ThisWorkbook section. Thank you!